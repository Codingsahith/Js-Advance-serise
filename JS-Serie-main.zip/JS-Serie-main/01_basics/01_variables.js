const fullName = "m.sahith reddy" //we an not change the value of the variable
var age = "21" // prefer to not to use var, because issues in block scope and functional scope
let course = "B.tech" // we can change the value of the variables
let place //if we don'tassign any value. it becomes as undefined valu
branch = "cse"

console.table([fullName,age,course,branch,place])