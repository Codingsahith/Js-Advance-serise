// data types are 2 types
// primitive data types and non-primitive datatypes

// primitive datatypes
let num = 23//integer or number
let Name = "sahith" // string ""
let float = 42.580 // float 0.000
let bool = true //or false
let bigInt = 3787908298 // big int- 78366982709
let state = null // it is an object
let place // undefined
let symbols // $ @ unique values

console.table([num, Name, float, bool, bigInt, state, typeof state, place, symbols])

// non primitive datatypes