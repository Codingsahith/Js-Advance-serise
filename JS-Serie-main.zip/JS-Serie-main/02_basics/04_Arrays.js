let myInfo = ["sahith",21,"Btech"] // arrays are represent has Square Brackets
// console.log(myInfo)

// visualizing array

let num = [1,2,3,4,5]
// console.log(num[0])
// console.log(num[1])
// console.log(num[2])
// console.log(num[3])


let info = ["sahith",21,"btech"]
// console.log(info[0]) // sahith
// console.log(info[0][0]) // s
// console.log(info[1]) // 21

//  Arrays are "mutable". mutable" means we can change the value from the variables.
let fruits = ["apple","mango","orange"]
 fruits[1] = "banana"
//  console.log(fruits[1]) // banana
//  console.log(fruits) // apple, banana, orange . the fruits value is changed

 let numbers = [1,2,3,4]
 numbers[0] = "sahith"
 numbers[1] = "vinesh"
 numbers[2] = "sri"
 numbers[3] = "cherry"

//  console.log(numbers)