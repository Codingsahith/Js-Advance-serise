// Switch Statement

let myAnime = ""

switch(myAnime){
    case "Blue lock" :
        console.log("My fav anime is Blue Lock")
        break;
    case "Naruto" :
        console.log("My fav anime is Naruto")
        break;
    case "Demon Slayers" :
        console.log("My fav anime is",myAnime)
        break;

default :
console.log("I dont like anime")
}