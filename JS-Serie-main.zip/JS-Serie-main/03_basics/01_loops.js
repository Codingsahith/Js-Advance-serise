// for loop
console.log("for loop")
// console.log("increment")
for(let i=0;i<=5;i++){ 
    // console.log(i)
}
// console.log("decrement")
for(let i=5;i>=0;i--){
    // console.log(i)
}


// print odd numbers
console.log("print odd numbers")
for(let i=1;i<=9;i=i+2){
    console.log(i)
}

// print even numbers
console.log("print even numbers")
for(let i=0;i<=10;i=i+2){
    console.log(i)
}


// print odd numbers
console.log("print odd numbers backward process")
for(let i=9;i>=1;i=i-2){
    console.log(i)
}

// print even numbers
console.log("print even numbers backward process")
for(let i=10;i>=0;i=i-2){
    console.log(i)
}